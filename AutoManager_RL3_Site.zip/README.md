# AutoManager — Painel RL3

Aplicativo web para controle de carros e despesas, com exportação para PDF e armazenamento local.

## Como usar

1. Acesse o site hospedado (ou abra o arquivo index.html localmente).
2. Adicione carros e registre despesas.
3. Exporte PDFs e backups JSON quando necessário.

---
Feito para uso interno da RL3.
